"""Platform-neutral repository connectors."""
